﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Results
/// </summary>
public class Results
{
    //variables for calculating the results
    public int extroversion { get; set; }
    public int agreeableness { get; set; }
    public int conscientiousness { get; set; }
    public int neuroticism { get; set; }
    public int opennessToExperience { get; set; }

    public Results()
    {
        //
        // TODO: Add constructor logic here
        //
    }
}